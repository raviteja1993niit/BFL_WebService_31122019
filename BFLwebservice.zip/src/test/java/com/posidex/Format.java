package com.posidex;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;

import com.posidex.exception.DAOException;
import com.posidex.ws.entity.CustomerRequest;

public class Format {
   
}


//~ Formatted by Jindent --- http://www.jindent.com
